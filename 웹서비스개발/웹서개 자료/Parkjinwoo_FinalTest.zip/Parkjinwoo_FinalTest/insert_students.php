{\rtf1\ansi\ansicpg949\cocoartf2867
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww14200\viewh15940\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 <?php\
\
$servername = "localhost";\
$username = "root";\
$password = "";\
$dbname = "final";\
\
$conn = new mysqli($servername, $username, $password, $dbname);\
\
if ($conn->connect_error) \{\
    die("Connection failed: " . $conn->connect_error);\
\}\
\
$student_id    = $_POST['student_id'];\
$student_name  = $_POST['student_name'];\
$department_id = $_POST['depaetment_id'];\
$birth_year    = $_POST['birth_year'];\
\
$sql = "INSERT INTO students (student_id, student_name, department_id, birth_year)\
        VALUES ('$student_id', '$student_name', '$department_id', $birth_year)";\
\
$result = $conn->query($sql);\
\
if ($result) \{\
    echo "Students \uc0\u53580 \u51060 \u48660 \u50640  \u49341 \u51077  \u50756 \u47308 ";\
\} else \{\
    echo "Error: " . $conn->error;\
\}\
\
$conn->close();\
?>\
}