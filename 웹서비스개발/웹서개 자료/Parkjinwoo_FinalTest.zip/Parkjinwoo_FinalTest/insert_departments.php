{\rtf1\ansi\ansicpg949\cocoartf2867
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\csgray\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\f0\fs24 \cf2 <?php\
\
$servername = "localhost";\
$username = "root";\
$password = "";\
$dbname = "final";\
\
$conn = new mysqli($servername, $username, $password, $dbname);\
\
if ($conn->connect_error) \{\
    die("Connection failed: " . $conn->connect_error);\
\}\
\
$department_id   = $_POST['depaetment_id'];\
$department_name = $_POST['department_name'];\
$office_location = $_POST['office_location'];\
\
$sql = "INSERT INTO departments (department_id, department_name, office_location)\
        VALUES ('$department_id', '$department_name', '$office_location')";\
\
$result = $conn->query($sql);\
\
if ($result) \{\
    echo "Departments \uc0\u53580 \u51060 \u48660 \u50640  \u49341 \u51077  \u50756 \u47308 ";\
\} else \{\
    echo "Error: " . $conn->error;\
\}\
\
$conn->close();\
?>}