import 'package:flutter/material.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'model/product.dart';
import 'model/products_repository.dart';

class DetailPage extends StatefulWidget {
  final Product product;
  const DetailPage({Key? key, required this.product}) : super(key: key);

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late bool isFavorited;

  @override
  void initState() {
    super.initState();
    isFavorited = ProductsRepository.isFavorite(widget.product);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detail')),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                InkWell(
                  onDoubleTap: () {
                    setState(() {
                      isFavorited = !isFavorited;
                      if (isFavorited) {
                        ProductsRepository.addFavorite(widget.product);
                      } else {
                        ProductsRepository.removeFavorite(widget.product);
                      }
                    });
                  },
                  child: Hero(
                    tag: 'hotel_image_${widget.product.id}',
                    child: Image.asset(
                      widget.product.assetName,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 300,
                    ),
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Icon(
                    isFavorited ? Icons.favorite : Icons.favorite_border,
                    color: isFavorited ? Colors.red : Colors.white,
                    size: 30.0,
                    shadows: const [
                      Shadow(
                        blurRadius: 10.0,
                        color: Colors.black45,
                        offset: Offset(2.0, 2.0),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Card(
              margin: const EdgeInsets.all(16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: List.generate(widget.product.stars, (i) {
                        return Icon(
                          Icons.star,
                          color: Colors.yellow[700],
                          size: 24.0,
                        );
                      }),
                    ),
                    const SizedBox(height: 12.0),
                    AnimatedTextKit(
                      animatedTexts: [
                        WavyAnimatedText(
                          widget.product.name,
                          textStyle: const TextStyle(
                            fontSize: 24.0,
                            fontWeight: FontWeight.bold,
                          ),
                          speed: const Duration(milliseconds: 200),
                        ),
                      ],
                      isRepeatingAnimation: true,
                    ),
                    const SizedBox(height: 16.0),
                    _buildInfoRow(
                      Icons.location_on,
                      widget.product.location,
                      Colors.blue,
                    ),
                    const SizedBox(height: 12.0),
                    _buildInfoRow(
                      Icons.phone,
                      widget.product.phoneNumber,
                      Colors.green,
                    ),
                    const Divider(height: 32.0),
                    Text(
                      widget.product.description,
                      style: const TextStyle(fontSize: 14.0, height: 1.5),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20.0),
        const SizedBox(width: 12.0),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 14.0))),
      ],
    );
  }
}
