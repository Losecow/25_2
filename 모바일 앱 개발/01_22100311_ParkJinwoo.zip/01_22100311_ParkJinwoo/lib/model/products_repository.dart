// Copyright 2018-present the Flutter authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import 'product.dart';

class ProductsRepository {
  static final List<Product> _favoriteHotels = [];

  static List<Product> get favoriteHotels => _favoriteHotels;

  static void addFavorite(Product product) {
    if (!_favoriteHotels.contains(product)) {
      _favoriteHotels.add(product);
    }
  }

  static void removeFavorite(Product product) {
    _favoriteHotels.remove(product);
  }

  static bool isFavorite(Product product) {
    return _favoriteHotels.contains(product);
  }

  static List<Product> loadProducts(Category category) {
    const allProducts = <Product>[
      Product(
        category: Category.accessories,
        id: 0,
        isFeatured: true,
        name: 'Polonia Hotel',
        stars: 3,
        location: 'al. Jerozolimskie 45, 00-692\nWarszawa, Poland',
        assetName: 'assets/1.jpeg',
        assetPackage: '',
        phoneNumber: '+48 22 123 45 67',
        description:
            'A historic hotel in the heart of Warsaw, offering classic elegance and modern amenities for a comfortable stay.',
      ),
      Product(
        category: Category.accessories,
        id: 1,
        isFeatured: true,
        name: 'Gyeongju Hilton',
        stars: 4,
        location: '484-7 Bomun-ro Gyeongju-si\nGyeongsangbuk-do, KR',
        assetName: 'assets/2.jpeg',
        assetPackage: '',
        phoneNumber: '+82 54-745-1234',
        description:
            'Enjoy serene views of Bomun Lake and discover the rich history of the Silla Dynasty at our luxurious hotel.',
      ),
      Product(
        category: Category.accessories,
        id: 2,
        isFeatured: false,
        name: 'Grand Hyatt Seoul',
        stars: 2,
        location: '322 Sowol-ro, Yongsan-gu\nSeoul, South Korea',
        assetName: 'assets/3.jpeg',
        assetPackage: '',
        phoneNumber: '+82 2-797-1234',
        description:
            'A luxurious urban retreat with stunning views of the Han River and Mount Namsan, providing world-class service.',
      ),
      Product(
        category: Category.accessories,
        id: 3,
        isFeatured: true,
        name: 'Shilla Stay Daejeon',
        stars: 3,
        location: '597, Dongdaejeon-ro, Dong-gu\nDaejeon, South Korea',
        assetName: 'assets/4.jpeg',
        assetPackage: '',
        phoneNumber: '+82 42-224-9100',
        description:
            'A stylish hotel offering smart, comfortable spaces perfect for both business and leisure travelers.',
      ),
      Product(
        category: Category.accessories,
        id: 4,
        isFeatured: false,
        name: 'The Westin Josun Busan',
        stars: 4,
        location: '67, Dongbaek-ro, Haeundae-gu\nBusan, South Korea',
        assetName: 'assets/5.jpeg',
        assetPackage: '',
        phoneNumber: '+82 51-749-7000',
        description:
            'Located by Haeundae Beach, offering breathtaking ocean views and premium wellness facilities.',
      ),
      Product(
        category: Category.accessories,
        id: 5,
        isFeatured: false,
        name: 'Lotte Hotel Jeju',
        stars: 4,
        location: '35, Jungmungwangwang-ro 72beon-gil\nSeogwipo, Jeju-do',
        assetName: 'assets/6.jpeg',
        assetPackage: '',
        phoneNumber: '+82 64-731-1000',
        description:
            'A premier resort hotel in Jeju with a beautiful garden, casino, and exceptional dining options.',
      ),
      Product(
        category: Category.home,
        id: 6,
        isFeatured: true,
        name: 'Signiel Busan',
        stars: 4,
        location: '30, Dalmaji-gil, Haeundae-gu\nBusan, South Korea',
        assetName: 'assets/7.jpeg',
        assetPackage: '',
        phoneNumber: '+82 51-922-1000',
        description:
            'Experience unparalleled luxury and service with panoramic views from Korea\'s second tallest building.',
      ),
      Product(
        category: Category.home,
        id: 7,
        isFeatured: false,
        name: 'Park Hyatt Seoul',
        stars: 2,
        location: '606, Teheran-ro, Gangnam-gu\nSeoul, South Korea',
        assetName: 'assets/8.jpeg',
        assetPackage: '',
        phoneNumber: '+82 2-2016-1234',
        description:
            'A top-tier luxury hotel in the heart of Gangnam, offering sophisticated interiors and exquisite cuisine.',
      ),
      Product(
        category: Category.home,
        id: 8,
        isFeatured: false,
        name: 'Four Seasons Hotel Seoul',
        stars: 4,
        location: '97, Saemunan-ro, Jongno-gu\nSeoul, South Korea',
        assetName: 'assets/9.jpeg',
        assetPackage: '',
        phoneNumber: '+82 2-6388-5000',
        description:
            'A landmark of luxury in Gwanghwamun, featuring world-class accommodations, dining, and spa.',
      ),
      Product(
        category: Category.clothing,
        id: 9,
        isFeatured: false,
        name: 'Conrad Seoul',
        stars: 1,
        location: '10, Gukjegeumyung-ro, Yeongdeungpo-gu\nSeoul, South Korea',
        assetName: 'assets/10.jpeg',
        assetPackage: '',
        phoneNumber: '+82 2-6137-7000',
        description:
            'Strategically located in Yeouido Business District, offering stunning river views and smart luxury.',
      ),
      Product(
        category: Category.clothing,
        id: 10,
        isFeatured: false,
        name: 'Ananti Hilton Busan',
        stars: 4,
        location: '268-32, Gijanghaean-ro, Gijang-eup\nGijang-gun, Busan',
        assetName: 'assets/11.jpeg',
        assetPackage: '',
        phoneNumber: '+82 51-509-1111',
        description:
            'A stunning oceanfront resort with a private beach, infinity pools, and a variety of leisure facilities.',
      ),
      Product(
        category: Category.clothing,
        id: 11,
        isFeatured: false,
        name: 'St. John\'s Hotel',
        stars: 4,
        location: '307, Changhae-ro, Gangneung-si\nGangwon-do, South Korea',
        assetName: 'assets/12.jpeg',
        assetPackage: '',
        phoneNumber: '+82 33-660-9000',
        description:
            'The largest hotel in Gangneung, right in front of Gangmun Beach, offering endless ocean views.',
      ),
      Product(
        category: Category.clothing,
        id: 12,
        isFeatured: false,
        name: 'Ramada Plaza Jeju',
        stars: 3,
        location: '125, Tapdong-ro, Jeju-si\nJeju-do, South Korea',
        assetName: 'assets/13.jpeg',
        assetPackage: '',
        phoneNumber: '+82 64-729-8100',
        description:
            'Korea\'s first coastal hotel, located right by the sea, offering a unique and refreshing experience.',
      ),
    ];
    if (category == Category.all) {
      return allProducts;
    } else {
      return allProducts.where((Product p) => p.category == category).toList();
    }
  }
}
