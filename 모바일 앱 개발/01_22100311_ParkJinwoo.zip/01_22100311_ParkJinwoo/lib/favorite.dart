import 'package:flutter/material.dart';
import 'model/product.dart';
import 'model/products_repository.dart';

class FavoriteHotelsPage extends StatefulWidget {
  const FavoriteHotelsPage({Key? key}) : super(key: key);

  @override
  _FavoriteHotelsPageState createState() => _FavoriteHotelsPageState();
}

class _FavoriteHotelsPageState extends State<FavoriteHotelsPage> {
  final List<Product> _favoriteHotels = ProductsRepository.favoriteHotels;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Favorite Hotels')),
      body: ListView.builder(
        itemCount: _favoriteHotels.length,
        itemBuilder: (context, index) {
          final product = _favoriteHotels[index];
          return Dismissible(
            key: ValueKey(product.id),
            direction: DismissDirection.endToStart,
            onDismissed: (direction) {
              setState(() {
                ProductsRepository.removeFavorite(product);
                _favoriteHotels.removeAt(index);
              });
            },
            background: Container(
              color: Colors.red,
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: const Icon(Icons.delete, color: Colors.white),
            ),
            child: ListTile(
              title: Text(
                product.name,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          );
        },
      ),
    );
  }
}
